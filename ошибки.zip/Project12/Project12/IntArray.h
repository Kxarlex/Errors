#pragma once

#ifndef INTARRAY_H
#define INTARRAY_H

#include <exception>

class bad_range : public std::exception {
public:
	const char* what() const noexcept override {
		return "Index out of range";
	}
};

class bad_length : public std::exception {
public:
	const char* what() const noexcept override {
		return "Invalid array length";
	}
};

class IntArray {
public:
	IntArray(int length);
	IntArray(const IntArray& other);
	~IntArray();

	int& operator[](int index);
	int& at(int index);

	void resize(int newLength);
	void reserve(int newLength);

	void insert(int value, int index);
	void erase(int index);

	int size() const;
	int capacity() const;

private:
	int* m_data;
	int m_length;
	int m_capacity;
};

#endif
