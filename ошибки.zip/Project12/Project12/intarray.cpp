#include "IntArray.h"

IntArray::IntArray(int length) :
	m_data(new int[length]), m_length(length), m_capacity(length)
{
}

IntArray::IntArray(const IntArray& other) :
	m_data(new int[other.m_capacity]), m_length(other.m_length), m_capacity(other.m_capacity)
{
	for (int i = 0; i < m_length; i++) {
		m_data[i] = other.m_data[i];
	}
}

IntArray::~IntArray()
{
	delete[] m_data;
}

int& IntArray::operator[](int index)
{
	if (index < 0 || index >= m_length) {
		throw bad_range();
	}
	return m_data[index];
}

int& IntArray::at(int index)
{
	if (index < 0 || index >= m_length) {
		throw bad_range();
	}
	return m_data[index];
}

void IntArray::resize(int newLength)
{
	if (newLength < 0) {
		throw bad_length();
	}

	if (newLength > m_capacity) {
		reserve(newLength);
	}

	for (int i = m_length; i < newLength; i++) {
		m_data[i] = 0;
	}

	m_length = newLength;
}

void IntArray::reserve(int newCapacity)
{
	if (newCapacity < m_length) {
		throw bad_length();
	}

	int* newData = new int[newCapacity];

	for (int i = 0; i < m_length; i++) {
		newData[i] = m_data[i];
	}

	delete[] m_data;
	m_data = newData;
	m_capacity = newCapacity;
}

void IntArray::insert(int value, int index)
{
	if (index < 0 || index > m_length) {
		throw bad_range();
	}

	if (m_length == m_capacity) {
		reserve(m_capacity * 2);
	}

	for (int i = m_length; i > index; i--) {
		m_data[i] = m_data[i - 1];
	}

	m_data[index] = value;
	m_length++;
}

void IntArray::erase(int index)
{
	if (index < 0 || index >= m_length) {
		throw bad_range();
	}

	for (int i = index; i < m_length - 1; i++) {
		m_data[i] = m_data[i + 1];
	}

	m_length--;
}

int IntArray::size() const
{
	return m_length;
}

int IntArray::capacity() const
{
	return m_capacity;
}