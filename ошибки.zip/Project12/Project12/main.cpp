
#include "IntArray.h"
#include <iostream>

int main()
{
	try {
		IntArray arr(-5);
	}
	catch (const bad_length& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	IntArray arr(5);

	try {
		arr[-1] = 10;
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr[5] = 10;
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.at(-1) = 10;
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.at(5) = 10;
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.resize(-5);
	}
	catch (const bad_length& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.reserve(3);
	}
	catch (const bad_length& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.insert(10, -1);
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.insert(10, 6);
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	arr.insert(10, 2);

	try {
		arr.erase(-1);
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	try {
		arr.erase(5);
	}
	catch (const bad_range& e) {
		std::cerr << "Caught exception: " << e.what() << std::endl;
	}

	arr.erase(2);

	std::cout << "Array size: " << arr.size() << std::endl;
	std::cout << "Array capacity: " << arr.capacity() << std::endl;

	return 0;
}